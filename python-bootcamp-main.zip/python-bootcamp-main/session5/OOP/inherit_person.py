#https://www.thegeekstuff.com/2019/03/python-oop-examples/


class Person:
  def __init__(self):
    pass

# Single level inheritance
class Employee(Person):
  def __init__(self):
    pass










# Multi-level inheritance
class Manager(Employee):
  def __init__(self):
    pass

# Multiple Inheritance
class Enterprenaur(Person, Employee):
  def __init__(self):
    pass
