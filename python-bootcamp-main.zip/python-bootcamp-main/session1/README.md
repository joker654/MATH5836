
 


### Conditional statements 

### loops

### Functions

### Arrays

### Recursion

### Numpy Arrays 