

### Reviews by participants

* "Rohit as the instructor has definitely laid a good foundation of Python programming. Plus, TransAI making it available on their youtube channel surely benefit those who could not make it to the live session and the public! Incredible effort, congratulations!"

* "Nice practical tutorials" 

* "The Python Bootcamp is absolutely fantastic. It starts from basic stuff and the difficulty increases step by step. It has built up Python foundation for me and enable everyone to understand the knowledge required before in touch with machine learning."

* "Awesome stuff"

* "Dr. Chandra did an amazing job in putting together the boot camp. The selection of examples were the best part of it. It started with a basic level and reached to a point where one can use it for research. I appreciate the effort. Excellent job done."

* "Dr Chandra's python bootcamp is a great way to learn python for anyone wishing to get better at coding. The activities are well explained and is much more effective than trying to learn by yourself."  ~  Kelvin Tang