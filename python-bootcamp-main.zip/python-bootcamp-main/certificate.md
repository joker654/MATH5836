

### Certificate of participation

* Hilary Albert, Sydney Australia. LinkedIn Hilary Albert
* Ahmad Hakiim Jamaluddin, School of Mathematics and Statistics, UNSW Sydney, Australia
* Rose Iataake, Tarawa, Kiribati
* Hanwen Xuan, Sydney, Australia [Linkedin](https://www.linkedin.com/in/hanwen-xuan-472aaa119/)
* Stephenson Guurau, City: Honiara, Country: Solomon Islands
* Kelvin Tang, UNSW Business School, Sydney. [Linkedin](https://www.linkedin.com/in/kelvin-tang-628aa815b/)