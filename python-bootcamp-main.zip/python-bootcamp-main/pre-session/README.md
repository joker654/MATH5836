#

## Basic information regarding python and anaconda installation here: 
* [windows](https://www.youtube.com/watch?v=5mDYijMfSzs)
* [mac](https://www.youtube.com/watch?v=daVgEXjv6DE)
* [linux](https://www.youtube.com/watch?v=WFswV4J2ZEs)

* [vs-code basics](https://www.youtube.com/watch?v=ORrELERGIHs)
* [intro github](https://www.youtube.com/watch?v=w3jLJU7DT5E)
* [github via gitkrekin](https://www.youtube.com/watch?v=ub9GfRziCtU)
 

## online interpreters you can use for the bootcamp:

* https://www.onlinegdb.com/online_python_compiler

* https://replit.com/   

## tutorial to follow
* https://www.programiz.com/python-programming/keywords-identifier

* https://www.programiz.com/python-programming/statement-indentation-comments

* https://www.programiz.com/python-programming/variables-constants-literals

* https://www.programiz.com/python-programming/variables-datatypes

* https://www.programiz.com/python-programming/function

* https://www.programiz.com/python-programming/function-argument

* https://www.programiz.com/python-programming/recursion